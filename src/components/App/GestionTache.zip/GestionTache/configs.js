var configs = {
  databaseConfig: "Wbu-Gestion-Tache"
};

export default {
  configs
};
